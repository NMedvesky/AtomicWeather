To install the needed modules navigate to the folder in a terminal and run the following command.

pip install -r requirements.txt

Then run the main.pyw file via the terminal or with another Python interpreter.